$(document).ready(function () {
    var table = $('#login_data').DataTable({

    });
    var table2 = $('#global_logs').DataTable({

    });
    var table3 = $('#global_attacks').DataTable({

    });
    var table4 = $('#plans').DataTable({

    });

    var table5 = $('#licenses').DataTable({

    });

    var table6 = $('#blacklists').DataTable({

    })
});