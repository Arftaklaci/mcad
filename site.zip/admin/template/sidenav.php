<?php
/**
 * Created by PhpStorm.
 * User: bas
 * Date: 20-4-19
 * Time: 19:44
 */
?>
<div class="left-sidenav">

    <ul class="metismenu left-sidenav-menu" id="side-nav">

        <li class="menu-title">Main</li>

        <li>
            <a href="../index"><i class="mdi mdi-monitor"></i><span>Return to main dashboard</span></span></a>
        </li>

        <li>
            <a href="index"><i class="mdi mdi-book"></i><span>Admin overview</span></span></a>
        </li>


        <li class="menu-title">Plan management</li>

        <li>
            <a href="plans"><i class="mdi mdi-currency-usd"></i><span>Plan management</span></span></a>
        </li>

        <li>
            <a href="licenses"><i class="mdi mdi-key"></i><span>License management</span></span></a>
        </li>

        <li class="menu-title">Rotation pool</li>

        <li>
            <a href="servers"><i class="mdi mdi-power"></i><span>Server management</span></span></a>
        </li>

        <li class="menu-title">Other</li>

        <li>
            <a href="news"><i class="mdi mdi-newspaper"></i><span>News management</span></span></a>
        </li>
        <li>
            <a href="tickets"><i class="mdi mdi-ticket"></i><span>User tickets</span></span></a>
        </li>
        <li>
            <a href="blacklist"><i class="mdi mdi-key"></i><span>Blacklist management</span></span></a>
        </li>

    </ul>
</div>
