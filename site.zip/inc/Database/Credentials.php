<?php
namespace mcspam;
Class Credentials {

    /**
     * @var array
     */
    public static $credentials = [
        'username' => "arifreis",
        'password' => "lwaherdaim",
        'host' => "localhost",
        'database' => "mcspam"
    ];
}